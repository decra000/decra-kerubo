// content-scripts/gemini.js
//
// DOM-fallback capture for gemini.google.com. Gemini's web UI is the
// least likely of the three to expose usage data anywhere accessible, so
// this leans entirely on the character-count heuristic. Selectors are
// best-effort against Gemini's custom-element structure and are the most
// likely of the three content scripts to need updating over time.

(function () {
  const SOURCE = "gemini";
  const USER_SELECTOR = "user-query";
  const MODEL_SELECTOR = "model-response";

  function scan() {
    document.querySelectorAll(USER_SELECTOR).forEach((el) => {
      if (el.dataset.ecoLogged) return;
      const text = el.innerText || "";
      if (!text.trim()) return;
      send("user", text);
      el.dataset.ecoLogged = "true";
    });
    document.querySelectorAll(MODEL_SELECTOR).forEach((el) => {
      if (el.dataset.ecoLogged) return;
      const text = el.innerText || "";
      if (!text.trim()) return;
      send("assistant", text);
      el.dataset.ecoLogged = "true";
    });
  }

  function send(role, text) {
    chrome.runtime.sendMessage({
      type: "USAGE_EVENT",
      source: SOURCE,
      role,
      text,
      timestamp: Date.now()
    });
  }

  const observer = new MutationObserver(() => {
    clearTimeout(window.__ecoTrackerDebounce);
    window.__ecoTrackerDebounce = setTimeout(scan, 500);
  });
  observer.observe(document.body, { childList: true, subtree: true });
  scan();
})();
