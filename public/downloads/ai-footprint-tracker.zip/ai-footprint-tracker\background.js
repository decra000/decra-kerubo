// background.js — MV3 service worker.
//
// Receives USAGE_EVENT messages from content scripts, turns them into
// footprint estimates, queues them in chrome.storage.local (so nothing is
// lost if the worker is suspended), and periodically flushes the queue to
// Supabase. Also relays auth actions from the popup.

import { estimateTokensFromText, estimateFootprint } from "./lib/estimator.js";
import {
  getStoredSession,
  signIn,
  signUp,
  signOut,
  insertUsageEvents,
  fetchUsageSince
} from "./lib/supabase-client.js";

const QUEUE_KEY = "eco_tracker_queue";
const FLUSH_ALARM = "eco-tracker-flush";
const FLUSH_INTERVAL_MINUTES = 2;
const MAX_QUEUE_LENGTH = 2000; // hard cap so a stuck sync can't grow storage unbounded
const ALLOWED_SOURCES = new Set(["claude", "chatgpt", "gemini"]);
const ALLOWED_ROLES = new Set(["user", "assistant", "unknown"]);
// Content scripts only run on these origins per manifest host_permissions;
// re-checked here so a future permissions change can't silently widen who
// can post USAGE_EVENT rows without a matching review of this allowlist.
const ALLOWED_CONTENT_ORIGINS = new Set([
  "https://claude.ai",
  "https://chatgpt.com",
  "https://gemini.google.com"
]);

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(FLUSH_ALARM, { periodInMinutes: FLUSH_INTERVAL_MINUTES });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === FLUSH_ALARM) flushQueue();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Reject anything not from this extension's own contexts (popup or its
  // content scripts) — defense in depth against externally_connectable
  // ever being added by mistake in a future change.
  if (sender.id !== chrome.runtime.id) return false;

  handleMessage(message, sender).then(sendResponse).catch((err) => {
    sendResponse({ ok: false, error: String(err && err.message ? err.message : err) });
  });
  return true; // keep the message channel open for the async response
});

async function handleMessage(message, sender) {
  if (!message || typeof message.type !== "string") {
    return { ok: false, error: "Malformed message" };
  }

  switch (message.type) {
    case "USAGE_EVENT":
      if (sender.tab) {
        const origin = safeOrigin(sender.url);
        if (!ALLOWED_CONTENT_ORIGINS.has(origin)) {
          return { ok: false, error: "Origin not allowed" };
        }
      }
      return queueUsageEvent(message);

    case "AUTH_SIGN_IN":
      return { ok: true, session: await signIn(message.email, message.password) };

    case "AUTH_SIGN_UP":
      return { ok: true, session: await signUp(message.email, message.password) };

    case "AUTH_SIGN_OUT":
      await signOut();
      return { ok: true };

    case "AUTH_GET_SESSION":
      return { ok: true, session: await getStoredSession() };

    case "GET_SUMMARY":
      return { ok: true, summary: await getSummary(message.sinceIso) };

    case "FLUSH_NOW":
      await flushQueue();
      return { ok: true };

    default:
      return { ok: false, error: `Unknown message type: ${message.type}` };
  }
}

function safeOrigin(url) {
  try {
    return new URL(url).origin;
  } catch {
    return "";
  }
}

async function queueUsageEvent(evt) {
  if (!ALLOWED_SOURCES.has(evt.source)) {
    return { ok: false, error: "Unknown source" };
  }
  const role = ALLOWED_ROLES.has(evt.role) ? evt.role : "unknown";
  // Text never leaves this function — only the derived token count does.
  // Cap it defensively so one pathological DOM node can't cause a huge
  // string to sit in memory while we compute its length.
  const text = typeof evt.text === "string" ? evt.text.slice(0, 50_000) : "";

  const estimatedTokens = estimateTokensFromText(text);
  const footprint = estimateFootprint(evt.source, estimatedTokens);

  const timestamp = Number(evt.timestamp);
  const createdAt = Number.isFinite(timestamp) ? new Date(timestamp) : new Date();

  const row = {
    source: evt.source,
    role,
    estimated_tokens: estimatedTokens,
    estimated_wh: footprint.wh,
    estimated_ml: footprint.ml,
    estimated_gco2: footprint.gco2,
    confidence: footprint.confidence,
    created_at: createdAt.toISOString()
  };

  const { [QUEUE_KEY]: queue = [] } = await chrome.storage.local.get(QUEUE_KEY);
  queue.push(row);
  // Drop oldest rows past the cap rather than growing storage unbounded if
  // sync has been failing for a long time.
  const trimmed = queue.length > MAX_QUEUE_LENGTH ? queue.slice(queue.length - MAX_QUEUE_LENGTH) : queue;
  await chrome.storage.local.set({ [QUEUE_KEY]: trimmed });

  // Try an opportunistic flush; harmless if it fails (e.g. not signed in yet).
  flushQueue().catch(() => {});

  return { ok: true, queued: row };
}

async function flushQueue() {
  const session = await getStoredSession();
  if (!session) return; // nothing to do until the user signs in

  const { [QUEUE_KEY]: queue = [] } = await chrome.storage.local.get(QUEUE_KEY);
  if (queue.length === 0) return;

  try {
    await insertUsageEvents(queue);
    await chrome.storage.local.set({ [QUEUE_KEY]: [] });
  } catch (err) {
    // Leave the queue intact — we'll retry on the next alarm tick.
    console.warn("[eco-tracker] flush failed, will retry:", err);
  }
}

async function getSummary(sinceIso) {
  const session = await getStoredSession();
  const { [QUEUE_KEY]: queue = [] } = await chrome.storage.local.get(QUEUE_KEY);

  let remoteRows = [];
  if (session) {
    try {
      remoteRows = await fetchUsageSince(sinceIso);
    } catch (err) {
      console.warn("[eco-tracker] could not fetch remote summary:", err);
    }
  }

  const rows = [...remoteRows, ...queue.filter((r) => r.created_at >= sinceIso)];

  const bySource = {};
  let totalWh = 0;
  let totalMl = 0;
  let totalGco2 = 0;
  let hasMl = false;
  let hasGco2 = false;

  for (const r of rows) {
    bySource[r.source] = bySource[r.source] || { wh: 0, count: 0, confidence: r.confidence };
    bySource[r.source].wh += Number(r.estimated_wh) || 0;
    bySource[r.source].count += 1;
    totalWh += Number(r.estimated_wh) || 0;

    if (r.estimated_ml != null) {
      totalMl += Number(r.estimated_ml);
      hasMl = true;
    }
    if (r.estimated_gco2 != null) {
      totalGco2 += Number(r.estimated_gco2);
      hasGco2 = true;
    }
  }

  return {
    totalWh: round(totalWh),
    totalMl: hasMl ? round(totalMl) : null,
    totalGco2: hasGco2 ? round(totalGco2) : null,
    eventCount: rows.length,
    pendingSync: queue.length,
    bySource,
    signedIn: !!session
  };
}

function round(n) {
  return Math.round(n * 1000) / 1000;
}
