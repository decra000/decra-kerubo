// popup/popup.js
// The popup never talks to Supabase directly — it just messages the
// background service worker, which owns the session and the queue.

const authView = document.getElementById("auth-view");
const statsView = document.getElementById("stats-view");
const statusDot = document.getElementById("status-dot");
const authError = document.getElementById("auth-error");

function send(message) {
  return chrome.runtime.sendMessage(message);
}

async function init() {
  const { session } = await send({ type: "AUTH_GET_SESSION" });
  if (session) {
    showStats();
    await loadSummary();
  } else {
    showAuth();
  }
}

function showAuth() {
  authView.classList.remove("hidden");
  statsView.classList.add("hidden");
  statusDot.classList.remove("online");
}

function showStats() {
  authView.classList.add("hidden");
  statsView.classList.remove("hidden");
  statusDot.classList.add("online");
}

async function loadSummary() {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const res = await send({ type: "GET_SUMMARY", sinceIso: startOfDay.toISOString() });
  if (!res.ok) {
    document.getElementById("pending-note").textContent = "Could not load summary.";
    return;
  }

  const { summary } = res;
  document.getElementById("total-wh").textContent = summary.totalWh.toFixed(3);
  document.getElementById("total-ml").textContent = summary.totalMl != null ? summary.totalMl.toFixed(2) : "—";
  document.getElementById("total-gco2").textContent = summary.totalGco2 != null ? summary.totalGco2.toFixed(3) : "—";
  document.getElementById("event-count").textContent = summary.eventCount;

  const bySourceEl = document.getElementById("by-source");
  bySourceEl.replaceChildren();
  for (const [source, data] of Object.entries(summary.bySource)) {
    const row = document.createElement("div");
    row.className = "source-row";

    const nameEl = document.createElement("span");
    nameEl.className = "source-name";
    const dotEl = document.createElement("span");
    dotEl.className = "source-dot";
    dotEl.style.background = `var(--${sanitizeSource(source)})`;
    nameEl.append(dotEl, labelFor(source));

    const valueEl = document.createElement("span");
    valueEl.className = "source-value";
    valueEl.append(`${data.wh.toFixed(3)} Wh`);

    const tagEl = document.createElement("span");
    tagEl.className = `confidence-tag ${sanitizeConfidence(data.confidence)}`;
    tagEl.textContent = data.confidence;
    valueEl.appendChild(tagEl);

    row.append(nameEl, valueEl);
    bySourceEl.appendChild(row);
  }

  const pendingNote = document.getElementById("pending-note");
  pendingNote.textContent = summary.pendingSync > 0
    ? `${summary.pendingSync} event(s) waiting to sync…`
    : "Fully synced.";

  // Lifetime totals, so it's clear history is kept — the grid above is
  // just today's slice, nothing is ever deleted.
  const allRes = await send({ type: "GET_SUMMARY", sinceIso: "1970-01-01T00:00:00.000Z" });
  const allTimeEl = document.getElementById("alltime-note");
  if (allRes.ok && allTimeEl) {
    const a = allRes.summary;
    const parts = [`${a.totalWh.toFixed(3)} Wh`];
    if (a.totalMl != null) parts.push(`${a.totalMl.toFixed(2)} mL`);
    if (a.totalGco2 != null) parts.push(`${a.totalGco2.toFixed(3)} g CO2e`);
    allTimeEl.textContent = `All time: ${parts.join(" · ")} · ${a.eventCount} messages`;
  }
}

const KNOWN_SOURCES = new Set(["claude", "chatgpt", "gemini"]);
function sanitizeSource(source) {
  return KNOWN_SOURCES.has(source) ? source : "border";
}

function labelFor(source) {
  return { claude: "Claude", chatgpt: "ChatGPT", gemini: "Gemini" }[source] || source;
}

const KNOWN_CONFIDENCE = new Set(["measured", "medium", "low"]);
function sanitizeConfidence(value) {
  return KNOWN_CONFIDENCE.has(value) ? value : "low";
}

/** Prevents double-submits and gives the user feedback while a request is in flight. */
function withBusy(button, fn) {
  return async (...args) => {
    if (button.disabled) return;
    button.disabled = true;
    const originalText = button.textContent;
    button.textContent = "…";
    try {
      await fn(...args);
    } finally {
      button.disabled = false;
      button.textContent = originalText;
    }
  };
}

function readCredentials() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  if (!email || !password) {
    authError.textContent = "Email and password are required.";
    return null;
  }
  if (password.length < 8) {
    authError.textContent = "Password must be at least 8 characters.";
    return null;
  }
  return { email, password };
}

const signInBtn = document.getElementById("sign-in-btn");
const signUpBtn = document.getElementById("sign-up-btn");

signInBtn.addEventListener("click", withBusy(signInBtn, async () => {
  authError.textContent = "";
  const credentials = readCredentials();
  if (!credentials) return;
  const res = await send({ type: "AUTH_SIGN_IN", ...credentials });
  if (!res.ok) {
    authError.textContent = res.error;
    return;
  }
  document.getElementById("password").value = "";
  showStats();
  await loadSummary();
}));

signUpBtn.addEventListener("click", withBusy(signUpBtn, async () => {
  authError.textContent = "";
  const credentials = readCredentials();
  if (!credentials) return;
  const res = await send({ type: "AUTH_SIGN_UP", ...credentials });
  if (!res.ok) {
    authError.textContent = res.error;
    return;
  }
  document.getElementById("password").value = "";
  authError.textContent = "Check your email to confirm your account, then sign in.";
}));

document.getElementById("sign-out-btn").addEventListener("click", async () => {
  await send({ type: "AUTH_SIGN_OUT" });
  showAuth();
});

document.getElementById("refresh-btn").addEventListener("click", async () => {
  await send({ type: "FLUSH_NOW" });
  await loadSummary();
});

init();
