// content-scripts/chatgpt.js
//
// DOM-fallback capture for chatgpt.com. Same approach as claude.js — see
// that file's header comment for the reasoning and caveats.

(function () {
  const SOURCE = "chatgpt";
  const MESSAGE_SELECTOR = '[data-message-author-role]';

  function scan() {
    const nodes = document.querySelectorAll(MESSAGE_SELECTOR);
    nodes.forEach((el) => {
      if (el.dataset.ecoLogged) return;
      const text = el.innerText || "";
      if (!text.trim()) return;
      chrome.runtime.sendMessage({
        type: "USAGE_EVENT",
        source: SOURCE,
        role: el.getAttribute("data-message-author-role") || "unknown",
        text,
        timestamp: Date.now()
      });
      el.dataset.ecoLogged = "true";
    });
  }

  const observer = new MutationObserver(() => {
    clearTimeout(window.__ecoTrackerDebounce);
    window.__ecoTrackerDebounce = setTimeout(scan, 500);
  });
  observer.observe(document.body, { childList: true, subtree: true });
  scan();
})();
