// content-scripts/claude.js
//
// DOM-fallback capture for claude.ai. Claude's frontend doesn't expose a
// stable, documented per-message token count in the page itself, so this
// watches the message list and estimates tokens from rendered text length
// (chars/4). Selectors here are best-effort and WILL need occasional
// updates if Claude's UI structure changes — that's the tradeoff of the
// DOM approach vs. network interception (see README "Known limitations").

(function () {
  const SOURCE = "claude";
  // Claude's chat UI marks turns with data-testid attributes on the
  // message container; fall back to a couple of alternates in case the
  // exact markup has shifted.
  const MESSAGE_SELECTORS = [
    '[data-testid="user-message"]',
    '[data-testid="assistant-message"]',
    '[data-message-author-role]'
  ];

  function roleFor(el) {
    if (el.matches('[data-testid="user-message"]')) return "user";
    if (el.matches('[data-testid="assistant-message"]')) return "assistant";
    return el.getAttribute("data-message-author-role") || "unknown";
  }

  function scan() {
    const nodes = document.querySelectorAll(MESSAGE_SELECTORS.join(","));
    nodes.forEach((el) => {
      if (el.dataset.ecoLogged) return;
      const text = el.innerText || "";
      if (!text.trim()) return;
      chrome.runtime.sendMessage({
        type: "USAGE_EVENT",
        source: SOURCE,
        role: roleFor(el),
        text,
        timestamp: Date.now()
      });
      el.dataset.ecoLogged = "true";
    });
  }

  const observer = new MutationObserver(() => {
    clearTimeout(window.__ecoTrackerDebounce);
    window.__ecoTrackerDebounce = setTimeout(scan, 500);
  });
  observer.observe(document.body, { childList: true, subtree: true });
  scan();
})();
